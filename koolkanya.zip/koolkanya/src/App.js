import React , { Component} from 'react';
import './App.css';
import Header from "./Components/HeaderComponent";
import Footer from "./Components/FooterComponent";

function App() {
  return (
    <div className="App">
     <Header/>
     <Footer/>
    </div>
  );
}

export default App;
