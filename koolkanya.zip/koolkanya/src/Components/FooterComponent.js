
import React , { Component} from 'react';
import '../../src/App.css';
import 'bootstrap/dist/css/bootstrap.css';
import  app from '../images/app-store.svg';
import fb from '../images/facebook-white.svg';
import insta from '../images/instagram-white.svg';
import play from '../images/play-store.svg';
import twitt from '../images/twitter-white.svg';
import windows from '../images/windows-store.svg';

class Footer extends Component{
    render() {

        return(
       
            <div className ="container-fluid">
            <div class="footer">
            <ul class="nav">
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#"> Terms and Conditions</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#"> Privacy Policy</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="#"> Collection Statement</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="#"> Help</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="#"> Manage Account</a>
                </li>
                </ul>
                <p class="textwhite">Copyright @ 2016 DEMO Streaming. All Rights Reserved.</p>

                <ul class="icon-part">
                    <li class="icon1"><img src ={fb} class="icons"/></li>
                    <li class="icon1"><img src ={twitt} class="icons"/></li>
                    <li class="icon1"><img src ={insta} class="icons"/></li>
                    <li class="icon1"><img src ={app} class="icon2 icon3"/></li>
                    <li class="icon1"><img src ={play} class="icon2"/></li>
                    <li class="icon1"><img src ={windows} class="icon2"/></li>
                </ul>

            </div>
           
            </div>
        )
    }
};

export default Footer;