import React , { Component} from 'react';
import '../../src/App.css';
import 'bootstrap/dist/css/bootstrap.css';


class Header extends Component{
    render() {

        return(
           

          <div className ="container-fluid">
          <nav className="navbar bg-info">
          <div class="main-text">DEMO <span> Streaming</span></div>
          <div class="right-cont">
          <form >
          <a className="active link-log" aria-current="page" href="#">Log in</a>
          <button className="btn btn-secondary " type="submit">Start your Free Trial</button>
            </form>
            </div>
          <div className="cls"></div>
             </nav>
            <nav className="header2 navbar"> <div class="main-text">Popular <span> Titles</span></div></nav>
          </div>

           

        )
    }
};

export default Header;